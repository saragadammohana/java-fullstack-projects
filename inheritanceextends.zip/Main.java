/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


	
	class Animal{
	    void eat(){
	        System.out.println(" Eating");
	    }
	   }
	   class Dog extends Animal{
	       void Bark(){
	           System.out.println(" Barking");
	       }
	   }
	   public class Main{
	   public static void main(String[] args) {
	   Dog d = new Dog();
	   d.eat();
	   d.Bark();
	}
	   }

