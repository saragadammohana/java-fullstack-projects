/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class EvenOddArray
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int arr[]=new int[5];
		int even=0;
		int odd=0;
		for(int i=0;i<arr.length;i++){
		    arr[i]=sc.nextInt();
		    if(arr[i]%2==0){
		        even++;
		    }
		    else{
		        odd++;
		    }
		}
		System.out.println("even="+even);
		System.out.println("odd="+odd);
		
	}
}
