/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class ReverseString
{
	public static void main(String[] args) {
		String str="happy";
		String rev="";
		for(int i=str.length()-1;i>=0;i--){
		     rev += str.charAt(i);
		}
		System.out.print("reverse string:"+rev);
	}
}
