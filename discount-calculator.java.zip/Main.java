/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter purchase amount:");
		double amount=sc.nextDouble();
		double finalamount;
		if(amount>5000){
		    finalamount=amount-(amount*0.20);
		}else{
		    finalamount=amount-(amount*0.10);
		}
		System.out.println("Final Bill:"+finalamount);
		}
		}
	

