public class Evenodd{
     int Numbers(int num){
         if(num %2==0)
         return 1;
         else
         return 0;
     }
     public static void main (String args[]){
         Scanner sc=new Scanner(system.in);
         System.out.println("Enter an number:");
         
         int num=sc.nextInt();
         int Evenodd=new int
         
     }
}