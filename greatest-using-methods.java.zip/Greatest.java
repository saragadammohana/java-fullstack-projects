/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


    public class Greatest
    {
       static int largest(int a,int b){
            if(a>b)
           
            return a;
            else
            
            return b;
        }
        public static void main(String args[]){
            
            int ans=largest(20,30);
            System.out.println(ans);
        }
    }

