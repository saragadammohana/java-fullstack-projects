/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.print("Enter units consumed:");
		int units=sc.nextInt();
		double bill;
		if(units<=100){
		    bill=units*2;
		}
		else if(units<=200){
		    bill=(100*2)+((units-100)*5);
		    
		}
		else{
		    bill=(100*2)+(100*5)+((units-200)*8);
		}
		System.out.println("Electricity Bill:"+bill);
	}
}
