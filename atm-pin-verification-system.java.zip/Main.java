/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		int correctpin=1234;
		System.out.print("Enter a ATM PIN:");
		int pin =sc.nextInt();
		if(pin==correctpin){
		    System.out.println("Access Granted");
		}else{
		    System.out.println("invalid PIN");
		}
		}
	}
