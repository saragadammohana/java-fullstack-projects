/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class CopyArray
{
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int arr1[]=new int[5];
	int arr2[]=new int[5];
	for(int i=0;i<arr1.length;i++){
	    arr1[i]=sc.nextInt();
	    arr2[i]=arr1[i];
	}
	for(int i=0;i<arr2.length;i++){
	    System.out.print(arr2[i]+" ");
	}
	}
}
