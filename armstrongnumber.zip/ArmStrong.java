/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class ArmStrong{
    public static void main(String args[]){
        Scanner sc=new Scanner (System.in);
        int num=sc.nextInt();
        int original=num;
        int sum=0;
        while(num>0){
            int digit=num%10;
            sum+=digit*digit*digit;
            num=num/10;
        }
        if(original==sum){
            System.out.println("Armstrong Number");
            
        }
        else{
            System.out.println("Not Armstrong");
        }
    }
}