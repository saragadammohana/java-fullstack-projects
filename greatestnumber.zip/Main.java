/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*************************************************************************/
/* GREATEST NUMBER*/
import java.util.*;

class Main{
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter how many numbers:");
        int n = sc.nextInt();
        int num,min,max;
        System.out.println("enter number 1:");
        num = sc.nextInt();
        min = max = num;
        for(int i=2;i<=n;i++){
            System.out.println("Enter number"+i+";");
             num = sc.nextInt();
             if(num<min){
                 min=num;
             }
             if(num>max){
                 max=num;
             }
        }
        System.out.println("smallest number:"+min);
        System.out.println("Greatest number:"+max);
    }
    
}
